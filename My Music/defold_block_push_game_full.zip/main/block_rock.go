game_object {
    id: "block_rock"
    components {
        id: "script"
        component: "/main/block_rock.script"
        type: "script"
    }
}