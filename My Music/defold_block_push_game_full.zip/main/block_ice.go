game_object {
    id: "block_ice"
    components {
        id: "script"
        component: "/main/block_ice.script"
        type: "script"
    }
}