game_object {
    id: "player"
    components {
        id: "script"
        component: "/main/player.script"
        type: "script"
    }
}