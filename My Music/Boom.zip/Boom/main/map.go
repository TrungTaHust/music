components {
  id: "map"
  component: "/main/map.tilemap"
}
